import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.xoshnaw.market',
  appName: 'XOSHNAW MARKET',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;

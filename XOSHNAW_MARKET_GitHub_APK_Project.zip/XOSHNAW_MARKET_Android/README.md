# XOSHNAW MARKET Android

This project wraps XOSHNAW MARKET with Capacitor.

## Build without a computer using GitHub Actions

1. Create a GitHub repository.
2. Upload all files/folders from this project to the repository.
3. Make sure `.github/workflows/build-apk.yml` is uploaded too.
4. Open the repository on GitHub.
5. Tap **Actions** → **Build XOSHNAW MARKET APK**.
6. Tap **Run workflow** (or push to main to start automatically).
7. When the workflow finishes, open the completed run.
8. Download the artifact named **XOSHNAW-MARKET-APK**.
9. Inside it is `app-debug.apk`.

For a production Play Store release, a signed release build is needed; this workflow creates a debug APK for testing/installation.
